RefinedTools_InternalState = RefinedTools_InternalState or {}

global.offhand = 0.0;
global.pitchAngle  = 0.0;
global.pitchAngleO = 0.0;
global.yawAngle    = 0.0;
global.yawAngleO   = 0.0;

local l        = (context.bl and 1) or -1
local player   = context.player
local item     = context.item
local matrices = context.matrices
local mainHand = context.mainHand
local smooth      = RefinedTools_InternalState["smoothCrossbow"]       or 0.0
local hadCrossbow = RefinedTools_InternalState["hadCrossbowPose"]      or false
local delay       = RefinedTools_InternalState["crossbowOffhandDelay"] or 1.0
local wasEquipped = RefinedTools_InternalState["crossbowWasEquipped"]  or false
local exit        = RefinedTools_InternalState["crossbowExitPose"]     or false
local isCharged = I:isChargedCrossbow(P:getMainItem(player))
local offItem   = P:getOffhandItem(player)
local isShield  = I:isOf(offItem, Items:get("minecraft:shield"))
local isLantern = I:isOf(offItem, Items:get("minecraft:lantern")) or I:isOf(offItem, Items:get("minecraft:soul_lantern")) or I:isOf(offItem, Items:get("minecraft:copper_lantern")) or I:isOf(offItem, Items:get("minecraft:exposed_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:weathered_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:oxidized_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:waxed_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:waxed_exposed_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:waxed_weathered_copper_lantern")) or I:isOf(offItem, Items:get("minecraft:waxed_oxidized_copper_lantern"))
local varas = I:isOf(item, Items:get("minecraft:fishing_rod")) or I:isOf(item, Items:get("minecraft:carrot_on_a_stick")) or I:isOf(item, Items:get("minecraft:warped_fungus_on_a_stick"))
local enxadas = I:isOf(item, Items:get("minecraft:mace")) or I:isOf(item, Items:get("minecraft:wooden_hoe")) or I:isOf(item, Items:get("minecraft:stone_hoe")) or I:isOf(item, Items:get("minecraft:copper_hoe")) or I:isOf(item, Items:get("minecraft:iron_hoe")) or I:isOf(item, Items:get("minecraft:diamond_hoe")) or I:isOf(item, Items:get("minecraft:golden_hoe")) or I:isOf(item, Items:get("minecraft:netherite_hoe")) or I:isOf(item, Items:get("minecraft:wooden_axe")) or I:isOf(item, Items:get("minecraft:stone_axe")) or I:isOf(item, Items:get("minecraft:copper_axe")) or I:isOf(item, Items:get("minecraft:iron_axe")) or I:isOf(item, Items:get("minecraft:diamond_axe")) or I:isOf(item, Items:get("minecraft:golden_axe")) or I:isOf(item, Items:get("minecraft:netherite_axe")) or I:isOf(item, Items:get("minecraft:wooden_pickaxe")) or I:isOf(item, Items:get("minecraft:stone_pickaxe")) or I:isOf(item, Items:get("minecraft:copper_pickaxe")) or I:isOf(item, Items:get("minecraft:iron_pickaxe")) or I:isOf(item, Items:get("minecraft:diamond_pickaxe")) or I:isOf(item, Items:get("minecraft:golden_pickaxe")) or I:isOf(item, Items:get("minecraft:netherite_pickaxe")) or I:isOf(item, Items:get("minecraft:wooden_shovel")) or I:isOf(item, Items:get("minecraft:stone_shovel")) or I:isOf(item, Items:get("minecraft:copper_shovel")) or I:isOf(item, Items:get("minecraft:iron_shovel")) or I:isOf(item, Items:get("minecraft:diamond_shovel")) or I:isOf(item, Items:get("minecraft:golden_shovel")) or I:isOf(item, Items:get("minecraft:netherite_shovel")) or I:isOf(item, Items:get("minecraft:wooden_sword")) or I:isOf(item, Items:get("minecraft:stone_sword")) or I:isOf(item, Items:get("minecraft:copper_sword")) or I:isOf(item, Items:get("minecraft:iron_sword")) or I:isOf(item, Items:get("minecraft:diamond_sword")) or I:isOf(item, Items:get("minecraft:golden_sword")) or I:isOf(item, Items:get("minecraft:netherite_sword"))
local blocking    = P:isSwimming(player) or P:isCrawling(player) or P:isClimbing(player)
local speed       = 1.5
local swingOffset = math.sin(math.min(context.mainHandSwingProgress * math.pi * speed, math.pi)) * 0.5
local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO

if I:isOf(item, Items:get("minecraft:name_tag")) then
    M:moveY(matrices, 0.25)
    M:moveZ(matrices, -0.05)
end

if not wasEquipped and isCharged then
    delay = 0
elseif delay < 1 then
    delay = math.min(delay + 0.02, 1)
end

if blocking then exit = true end

if exit then
    smooth = math.max(smooth - 0.08, 0)
    if smooth == 0 then
        exit        = false
        hadCrossbow = false
    end
elseif delay >= 1 then
    if isCharged then
        hadCrossbow = true
        smooth = math.min(smooth + 0.05, 1)
    elseif hadCrossbow then
        smooth = math.max(smooth - 0.05, 0)
        if smooth == 0 then hadCrossbow = false end
    else
        smooth = 0
    end
else
    smooth = 0
end

RefinedTools_InternalState["smoothCrossbow"]       = smooth
RefinedTools_InternalState["hadCrossbowPose"]      = hadCrossbow
RefinedTools_InternalState["crossbowOffhandDelay"] = delay
RefinedTools_InternalState["crossbowWasEquipped"]  = isCharged
RefinedTools_InternalState["crossbowExitPose"]     = exit

local se = Easings:easeInOutSine(smooth)

if I:isOf(item, Items:get("minecraft:crossbow")) and P:isUsingItem(player) and not isCharged and mainHand then
    M:moveX(matrices, -0.2)
    M:moveZ(matrices, -0.2)
    M:rotateY(matrices, -20)
    return
end

if smooth > 0 then
    if not I:isEmpty(offItem) and not mainHand then
        local offhandSwingX   = -swingOffset * 0.5
        local offhandSwingZ   = -swingOffset * 0.3
        local offhandSwingRot =  swingOffset * 25

        if isShield then
            M:moveX(matrices, (-0.85 * se) + offhandSwingX)
            M:moveY(matrices, -0.05 * se)
            M:moveZ(matrices, (-0.6 * se) - offhandSwingZ)
            M:rotateX(matrices, 30 * se)
            M:rotateY(matrices, (-50 * se) + offhandSwingRot)
            M:rotateZ(matrices, 70 * se)
            return
        end

        if isLantern then
            M:moveX(matrices, (-0.72 * se) + offhandSwingX)
            M:moveY(matrices, -0.35 * se)
            M:moveZ(matrices, (-0.5 * se) - offhandSwingZ)
            M:rotateX(matrices, 30 * se)
            M:rotateY(matrices, (-60 * se) + offhandSwingRot)
            M:rotateZ(matrices, 80 * se)
            return
        end

        M:moveX(matrices, (-0.7 * se) + offhandSwingX)
        M:moveY(matrices, -0.04 * se)
        M:moveZ(matrices, (-0.5 * se) - offhandSwingZ)
        M:rotateX(matrices, 30 * se)
        M:rotateY(matrices, (-50 * se) + offhandSwingRot)
        M:rotateZ(matrices, 70 * se)
        return
    end

    if delay == 1 and isCharged and I:isEmpty(offItem) then
        offhand = -0.1
    end

    if mainHand then
        M:moveX(matrices, -0.35 * se)
        M:moveZ(matrices, (-0.40 * se) + (swingOffset * 0.2))
    else
        local emptySwingX = -swingOffset * 0.4
        M:moveX(matrices, (-0.80 * se) + emptySwingX)
        M:moveZ(matrices, -0.30 * se)
        M:moveY(matrices, (0.10 * se) + (swingOffset * 0.2))
        M:rotateY(matrices, (-80 * se) + (swingOffset * 30))
        M:rotateZ(matrices, 10 * se)
    end
end

if varas then
    M:rotateX(matrices, -0)
    M:rotateY(matrices, -0 * l)
    M:moveY(matrices, 0.0)
    M:moveX(matrices, -0.0 * l)
    M:moveZ(matrices, -0.0)
    return
end

if enxadas then
    M:rotateX(matrices, 10)
    M:moveY(matrices, -0.1)
    M:moveX(matrices, 0.0)
    M:moveZ(matrices, 0.06)
    return
end