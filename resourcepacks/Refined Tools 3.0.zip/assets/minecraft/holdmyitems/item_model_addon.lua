RefinedTools_InternalState = RefinedTools_InternalState or {}

global.pitchAngle           = 0.0;
global.yawAngle             = 0.0;
global.pitchAngleO          = 0.0;
global.yawAngleO            = 0.0;
global.GHP_disableShearing  = 0.0;
global.GHP_isActive         = 0.0;
global.GHP_prevIsActive     = 0.0;
global.GHP_customShearsMPA  = 0;
global.GHP_leftShearsStart  = 0;
global.GHP_leftShearsEnd    = 29;
global.GHP_rightShearsStart = 30;
global.GHP_rightShearsEnd   = 59;
global.GHP_leftShearsRot    = 12.5;
global.GHP_rightShearsRot   = -12.5;

local l        = (data.bl and 1) or -1
local player   = data.player
local item     = data.item
local mainHand = data.mainHand
local climbing    = P:isClimbing(player)
local swimming    = P:isSwimming(player)
local crawling    = P:isCrawling(player)
local interacting = interact
local breaking    = blockBreaking
local active = climbing or swimming or crawling or interacting or breaking
local isHandPosesActive = (GHP_prevIsActive ~= GHP_isActive)
local ptAngle = (mainHand and pitchAngle) or pitchAngleO
local ywAngle = (mainHand and yawAngle) or yawAngleO
local carrot = {"minecraft:carrot_on_a_stick"}
local fungus = {"minecraft:warped_fungus_on_a_stick"}

local function isIn(list)
    for _, id in ipairs(list) do
        if I:isOf(item, Items:get(id)) then return true end
    end
    return false
end

if I:isOf(data.item, Items:get("minecraft:fishing_rod")) then
    animator:rotateZ(0, 29, -ywAngle * l, 0.5, 1.8, 0.5)
    animator:rotateX(0, 29, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 29, 0.05)
end

if isIn(carrot) then
    animator:rotateZ(0, 5, -ywAngle * l, 0.5, 1.8, 0.5)
    animator:rotateX(0, 5, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 5, 0.05)
    animator:rotateZ(20, 51, -ywAngle * l, 0.5, 1.8, 0.5)
    animator:rotateX(20, 51, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(20, 51, 0.05)
    return
end

if isIn(fungus) then
    animator:rotateZ(0, 5, -ywAngle * l, 0.5, 1.8, 0.5)
    animator:rotateX(0, 5, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(0, 5, 0.05)
    animator:rotateZ(20, 31, -ywAngle * l, 0.5, 1.8, 0.5)
    animator:rotateX(20, 31, M:clamp(P:getPitch(player) / 2.5, -20, 90) + ptAngle, 0, 1.8, 0.5)
    animator:moveZ(20, 31, 0.05)
    return
end

GHP_customShearsMPA  = GHP_customShearsMPA  + 1
GHP_leftShearsStart  = 0
GHP_leftShearsEnd    = 29
GHP_rightShearsStart = 30
GHP_rightShearsEnd   = 59
GHP_leftShearsRot    = 12.5
GHP_rightShearsRot   = -12.5

GHP_prevIsActive = GHP_isActive